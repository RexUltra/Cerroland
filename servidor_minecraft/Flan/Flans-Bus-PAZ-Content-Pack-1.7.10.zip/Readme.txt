Package Readme
-------------------------------------------------------------------------------
Name:				Bus PAZ pack

Version-No.:			1.7.10b
-------------------------------------------------------------------------------
Author:				ValikVIP

Contact:			-
-------------------------------------------------------------------------------
Mc-Version:			1.7.10

Flans Mod Version:		1.2

Depencies:			Minecraft-SMP Parts Package 1.7.10b

Build with Forge Version:	1.7.10-10.13.0.1180
-------------------------------------------------------------------------------
This Package is free to download on www.minecraft-smp.de. 

If you downloaded it somewhere else or payed for it (single or as part of a
compilation) please report this to manus@minecraft-smp.de.